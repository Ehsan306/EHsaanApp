import React, { Component } from 'react';
import {Link} from 'react-router-dom';
import logo from './123.png';
import styled from 'styled-components';
import {ButtonContainer} from "./Button";

export default class Navbar extends Component {
    state = {  }
    render() { 
        return ( 
            <NavWrapper className="navbar navbar-expand-sm navbar-light px-sm-5">
                {/*
                    https://www.iconfinder.com/icons/2135922/mobile_mobile_shopping_tablet_icon
                */}
             <Link to = '/'>
             <img src={logo}  alt="store" 
             width="20%" height="20%"
             className="navbar-brand" />
             </Link>
             
            
            <Link to = "/cart" className="ml-auto">
                
                <ButtonContainer>
                    <span className="mr-2">
                        <i className="fas fa-cart-plus" />
                    </span>
                    Cart
                </ButtonContainer>
                    
                
            </Link>
            </NavWrapper>
         );
    }
} 
    

const NavWrapper = styled.nav`
background: lightblue;
.nav-link{
    color: var(--mainWhite) !important;
    font-size: 3rem;
    text-transform: capitalize !important;
}
`;

 